% narx3.m
% program for nonlinear autoregression exogenous system 3: example 3 in
% Wen's paper

clear 
clc
close all

b_left = 0; b_right = 1;
n = 6;
mi = 6;   % mi is the maximum size for each function, mi=1 is for additive model
shares = 10;  % length and division of each dimension is equal
Mmax = 40;  % the maximum number of basis functions
load('/Users/Jun/Downloads/EHH/data/narendra.mat');
u_interval = [min(u), max(u)];
y_interval = [min(yout), max(yout)];

u_id = 1 : 3;
y_id = 1 : 3;

[phi, yphi] = arrange_phi(u, yout, u_id, y_id, u_interval, y_interval);



% identification result with the AHH procedure
tic

[ BBf_a, Bf_a, coe_a, errm_a ] = ahh( n, b_left, b_right, phi, yphi, shares, mi, Mmax);

Err_app_ahh = errm_a

toc

% test error for AHH algorithm
L2 = 200;
N2 = L2 - 3;
x_ch = [];y_ch = [];
y_ch( 1 : 3 ) = y_v( 1 : 3 );
xx_min = [repmat(y_interval(1), 1,3), repmat(u_interval(1), 1, 3)];
xx_max = [repmat(y_interval(2), 1,3), repmat(u_interval(2), 1, 3)];
%     x_0 = arrange_phi(u_v, y_v, u_id, y_id, u_interval, y_interval);


for t = 4 : L2
    x_ch( t - 3 , : ) = [ y_ch( t - 1 ), y_ch( t - 2 ), y_ch( t - 3 ), u_v( t - 1 ), u_v( t - 2 ) u_v( t - 3 )] ;
    x_0 = ( x_ch( t - 3, : ) - xx_min ) ./ ( xx_max - xx_min );
    y_ch( t ) = ahh_result( Bf_a, coe_a, x_0 );
end

y_ahh = y_ch;
Err_pre_ahh  = norm( y_ahh - y_v )^2 / norm( y_v - mean( y_v ) )^2
figure
axes( 'Fontsize',18)
plot( y_ahh, 'r','linewidth',1.5 )
hold on
plot( y_v,':','linewidth',1.5)
xlabel('t','fontsize',24 )
ylabel('y','fontsize',24 )



