function ysim=sys_simulation_ehh_state(u_v, y_v, B, stem_B, weights, ps)

Lv = length(u_v);
u_v = reshape(u_v, Lv, 1);
y_v = reshape(y_v, Lv, 1);
x0 = zeros(1, 2);

ysim = zeros(Lv, 1);

umax = ps.xmax(end);
umin = ps.xmin(end);
u_v = (u_v - umin)/(umax - umin);



for t = 1 : Lv
    phi(t, :) = [x0, u_v(t)];
    for ii = 1 : 2
        xt1(ii) = cal_node_value(B{ii}, stem_B{ii}, phi(t,:))*weights{ii};
    end
    x0 = xt1;
end
ysim = phi(:, 1);
