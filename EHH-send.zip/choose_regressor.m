%--choose_regressor.m---

clear
close all

%%--data--
% %--example 1--
% na=5; nb=5;
% [phi, yphi, u_v, y_test,umin, umax, ymin, ymax]=data_generation_narx2(na,nb);
%--example bouc-wen--
load('/Users/Jun/Downloads/EHH/data/bouc-wen.mat');
na=15;%1;
nb=15;
ulag = 1;
u_interval = [min(u), max(u)];%[-205,210];%
y_interval = [min(y), max(y)];%[-0.0025,0.0025];%
u = reshape(u,8192,5);
y = reshape(y,8192,5);
ytest1 = yval_multisine';
ytest2 = yval_sinesweep';

[phi, yphi]=arrange_uy(u(:,1), y(:,1), na, nb, u_interval, y_interval,ulag);

% [phi, yphi]=arrange_uy_0829(u(:,1), y(:,1), na, nb, ulag);
len_phi = size(phi, 1);


%%--prehandling--
[U,S,V] = svd(phi);
sum_eigen = sum(diag(S));
for ii=1:size(S,2)
    vii = S(1:ii, 1:ii);
    if sum(diag(vii))>0.99*sum_eigen
        len_vector = ii;
        break
    end
end
Vl = V(:, 1:len_vector);
phi = phi*Vl;
phi_min = min(phi);
phi_max = max(phi);
phi = (phi-repmat(phi_min,len_phi, 1))./repmat(phi_max - phi_min, len_phi, 1);


%%--train--
x_train=phi;
y_train=yphi;
config_file = 'config.ini';
parameters = init_par(config_file);
parameters.lambda=[1e-8,1e-7, 1e-6, 1e-5];
% parameters.structure=[300];


[B, weights, id_var_bb, stem_B, adjacency_matrix, id_layer, lof, err, stds, lambda_opt] = forward(x_train, y_train, parameters);

layers = [B, num2cell(id_layer,2), num2cell(stem_B,2)];
for i = 1:size(layers, 1)
    layers{i, 4} = layers{i, 1}(:, 2);
end

% [sigma, minusgcv] = anova_ehh(layers, weights, x_train, y_train, parameters);
% [~,bb]=sort(sigma(:,2),'descend');
% sigma_gcv = [sigma(bb,:),minusgcv(bb,2)]

[~,ysim1] = sys_simu_ehh_reduced(na, nb, uval_multisine, B, stem_B, weights, u_interval, y_interval,ulag, phi_min, phi_max, Vl);
[~,ysim2] = sys_simu_ehh_reduced(na, nb, uval_sinesweep, B, stem_B, weights, u_interval, y_interval,ulag, phi_min, phi_max, Vl);

20*log10(sqrt(norm(ysim1-ytest1)^2/8192))
20*log10(sqrt(norm(ysim2-ytest2)^2/153000))
