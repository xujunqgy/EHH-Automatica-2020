function [phi, yphi]=arrange_uy_0829(u, y, na, nb,ulag)
% arranged train data without uniscale
% na and nb may be intervals for u and y

Lt=length(u);


u = reshape(u,Lt,1);
y = reshape(y,Lt,1);
if length(na)==1 & length(nb)==1
    nstart = max(na,nb);
    
    for t=nstart+1:Lt
        id=t-nstart;
        reg1 = y(t-1:-1:t-nb);
%         reg2 = (u(t-1:-1:t-na)-umin)/(umax - umin);
        reg2 = u(t-ulag:-1:t-na);
        phi(id,:)=[reg1', reg2'];
    end

end
yphi=y(nstart+1: Lt);