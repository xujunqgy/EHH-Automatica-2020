function [phi, yphi] = arrange_uy(u, y, na, nb)

% arranged train data
% na and nb may be intervals for u and y

Lt=length(u);

u = reshape(u,Lt,1);
y = reshape(y,Lt,1);
if length(na)==1 & length(nb)==1
    nstart = max(na,nb);
    
    for t=nstart+1:Lt
        id=t-nstart;
        reg1 = y(t-1:-1:t-nb);
        reg2 = u(t-1:-1:t-na);
        phi(id,:)=[reg1', reg2'];
    end
else
    if isempty(na)
        nstart = max(nb);
    else
        nstart = max(max(nb), max(na));
    end
    for t = nstart+1:Lt
        reg1 = []; reg2 = reg1;

        id = t-nstart;
        for ii = 1: length(nb)
            reg1 = [reg1, y(t-nb(ii))];
        end
        for ii = 1:length(na)
            reg2 = [reg2, u(t-na(ii))];
        end
        phi(id,:) = [reg1, reg2];
    end
end
yphi=y(nstart+1: Lt);