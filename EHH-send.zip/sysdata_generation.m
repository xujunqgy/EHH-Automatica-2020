 function [phi, yphi]=data_generation_narx1(na,nb,nu,ny)
%- na is the assumed lag for u
%- nu is the actual lag for u
%- nb is the assumed lag for y
%- ny is the actual lag for y
%- u and y are all in 1-dimension, for multiple dimensions, later

L=8000;
%% train data generation
yout = zeros(L, 1);
ns1 = max(nu, ny);

for t = 1 : L
    u( t ) = unifrnd( -1 , 1 );
end
    
    
for t = ns1 : L
    yout( t ) = ( yout( t - 1 ) * yout( t - 2 ) * yout( t - 3 ) * u( t - 2 ) * ( yout( t - 3 ) - 1 ) + u( t - 1 ) ) / ( 1 + yout( t - 2 )^2 + yout( t - 3 )^2 ) + normrnd( 0, 0.13 );
end
    
    
%% test data generation    
   y_v = zeros(L, 1); 
    
    for t = 1 : 500
        u_v( t ) = sin( 2 * pi * t / 250);
    end
    for t = 501 : 800
        u_v( t ) = 0.8 * sin( 2 * pi * t / 250 ) + 0.2 * sin( 2 * pi * t / 25);
    end
    
    
    
    for t = 4 : 800
        y_v( t ) = ( y_v( t - 1 ) * y_v( t - 2 ) * y_v( t - 3 ) * u_v( t - 2 ) * ( y_v( t - 3 ) - 1 ) + u_v( t - 1 ) ) / ( 1 + y_v( t - 2 )^2 + y_v( t - 3 )^2 );% + normrnd( 0 , 0.13 );
    end
    

%% train data 
nstart=max(na,nb);
N=length(u);
u=(u-umin)/(umax-umin);
y=(y-ymin)/(ymax-ymin);
u=reshape(u,N,1);
y=reshape(y,N,1);
for t=nstart+1:N
    id=t-nstart;
    phi(id,:)=[u(t:-1:t-na)',y(t-1:-1:t-nb)'];
end
yphi=y(nstart+1:N);