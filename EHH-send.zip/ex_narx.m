%--ex_narx.m---
clear
close all
% generate the train data and test data
% load('/Users/Jun/Downloads/EHH/data/narx1-auto.mat');
nu=1;ny=1;  % is fixed for each nonlinear system

na=5;
nb=5;
% umin=-1; umax=1;
% ymin=-1.5; ymax=1.5;
dbstop if error

for T_gen=1:10
    
    [phi, yphi, u_v, y_test,umin, umax, ymin, ymax]=data_generation_narx2(na,nb);
%     [phi, yphi, u_v, y_test,umin, umax, ymin, ymax]=data_generation_narx1(na,nb);
    u_interval = [umin, umax];
    y_interval = [ymin, ymax];
    ulag = 1;
    dim = size(phi,2);
    dim_y = size(yphi,1);
    Ntrain=length(yphi);
    Ntest=length(y_test);
    
    
    %% Parameter Initialiation
    config_file = 'config.ini';
    parameters = init_par(config_file);
    penalty = parameters.penalty;  % complexity penalty
    num_train = parameters.num_train;  % number of training
    percent = parameters.percent; % percentage of training data
    parameters.lambda=[1e-2, 1e-1,1];%, 1e-2, 1e-1];%; should be tuned for specific problem?
    %%
    num_train=10;%100;%floor(Ntrain/ns);
    ns = length(yphi)-10:length(yphi)-1;  %phi(1:101),...,phi(1:110) are used for training the nn
    x_v = phi;
    y_v = yphi;

%     ns = floor(Ntrain/num_train)*num_train;%7900;%number of samples used for single network generation
    
    structure_candidate={0,40}; %0,[20],[20,20],[20,20,20,20],0 for variable selection
    nstructure=length(structure_candidate);
    
    adjacency_matrices = cell(num_train, 1);
    stem_BBs = cell(num_train, 1);
    Bs = cell(num_train, 1);
    Bs_first = cell(num_train, 1);
    layer_indices = cell(num_train, 1);
    weights_all = cell(num_train, 1);
    lofs = zeros(num_train, 1);
    errs = zeros(num_train, 1);
    stds_all = zeros(num_train, 1);
    yahh = zeros(length(y_test), num_train);
    err_test = zeros(num_train, 1);
    std_test =  zeros(num_train, 1);
%     restriction{1}=[1 2 3 5 6];
%     indices = crossvalind('Kfold',ns,num_train);
        tic

    for TT = 1:num_train   %num_train is the training times
        x_train=phi(1:ns(TT),:);
        y_train=yphi(1:ns(TT));
        lTT=randi(nstructure);
        parameters.structure=structure_candidate{lTT};
        
        [B, weights, id_var_bb, stem_B, adjacency_matrix, id_layer, lof, err, stds, lambda_opt] = forward(x_train, y_train, parameters);
%         [B, weights, id_var_bb, stem_B, adjacency_matrix, id_layer, lof, err, stds, lambda_opt]=forward_restricted(x_train, y_train, parameters, restriction);

        
        num_nodes=size(stem_B,1);
        pos_row_id = find(stem_B(:,1)>0);  %positive row index, the rows for the first hidden layer are zero
        if isempty(pos_row_id)   % all the neurons are in the first hidden layer
            num1layer = num_nodes;
        else
            num1layer = num_nodes - length(pos_row_id);  % number of nodes in the first hidden layer
        end
        B_first = cell2mat(B(1:num1layer));  % basis function matrix in the first hidden layer
        
        
        Bs_first{TT} = B_first;
        adjacency_matrices{TT} = adjacency_matrix;
        stem_BBs{TT} = stem_B;
        Bs{TT} = B;
        layer_indices{TT} = id_layer;
        LAYERS{TT}=[B, num2cell(id_layer,2), num2cell(stem_B,2)];
        LAYERS=LAYERS';
        weights_all{TT} = weights;
        
        lofs(TT)  = lof;
        errs(TT) = err;
        stds_all(TT) = stds;
       
       
        [~, yahh(:,TT)] = sys_simulation_ehh(na, nb, u_v, B, stem_B, weights, u_interval, y_interval,ulag);
        err_test(TT) = sqrt(norm( yahh(:,TT) - y_test )^2 / Ntest);%norm( y_test - mean( y_test ) )^2;%sqrt(/Ntest);%
        std_test(TT) = std( yahh(:,TT) - y_test);
        
        f_ehh_TT(:,TT)=cal_node_value(B,stem_B,x_v)*weights;%x_validate
        
    end
    P=2*f_ehh_TT'*f_ehh_TT;
    P=(P+P')/2;
    q=-2*f_ehh_TT'*y_v;%y_validate;
    r=y_v'*y_v;%validate;
    lb=zeros(num_train,1);
    [ratio,~]=quadprog(P, q, [], [],[],[],lb, []);
    
    id_non0=find(ratio>1e-5);
    [layers, weights] = merge_net2(LAYERS(id_non0,:), weights_all(id_non0,:), ratio(id_non0), parameters );
    B_tt=layers(:,1);
    stem_B_tt=cell2mat(layers(:,3));
    id_layer_tt=cell2mat(layers(:,2));
    
%     [sigma, minusgcv] = anova_ehh(layers, weights, phi, yphi, parameters);
%     [~,bb]=sort(sigma(:,2),'descend');
%     [sigma(bb,:),minusgcv(bb,2)]

    

    
    [~, yt ]= sys_simulation_ehh(na, nb, u_v, B_tt, stem_B_tt, weights, u_interval, y_interval, ulag);
    
%     yt=yahh*ratio;
    err_gen(T_gen)=sqrt(norm(yt-y_test)^2/Ntest);%norm(y_test-mean(y_test))^2;
    rsse(T_gen) = norm(yt-y_test)^2/norm(y_test-mean(y_test))^2;

    time_gen(T_gen)=toc;
end

figure
plot(y_test,'k:','linewidth',1.5)
hold on
plot(yt,'linewidth',1.5)
xlabel('Times Instant','fontsize',14)
ylabel('The outputs','fontsize',14)




