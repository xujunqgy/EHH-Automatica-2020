function [xsim, ysim]=sys_simu_ehh_reduced(na, nb, u_v, B, stem_B, weights, u_interval, y_interval,ulag, phi_min, phi_max, Vl)

Lv = length(u_v);
u_v = reshape(u_v, Lv, 1);
% y_v = reshape(y_v, Lv, 1);
umin = u_interval(1);
umax = u_interval(2);
ymin = y_interval(1);
ymax = y_interval(2);
ysim = zeros(Lv, 1);
% ulag = 0;%2;

ns = max(na,nb);
xsim = zeros(Lv, na+nb+1-ulag);
% ysim(1:ns)=y_v(1:ns);

for t = ns+1 : Lv
    reg1 = (ysim(t-1:-1:t-nb)-ymin)/(ymax - ymin);
    %         reg2 = (u_v(t-1:-1:t-na)-umin)/(umax-umin);
    reg2 = (u_v(t-ulag:-1:t-na)-umin)/(umax-umin);
    xsim( t, : ) = [ reg1', reg2'];
    phi_t = xsim(t, :)*Vl;
    phi_t = (phi_t-phi_min)./(phi_max-phi_min);
    ysim( t ) = cal_node_value( B, stem_B, phi_t )*weights;
end


