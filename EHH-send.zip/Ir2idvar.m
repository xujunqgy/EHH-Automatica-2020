function id_var_bb = Ir2idvar( Ir, B_first )
% function that convert the interaction matrix to id_var_bb
N = size(Ir, 1);
for jj = 1:N
    v = Ir(:, jj);
    v1 = find( v >0 );
    id_var_bb{jj} = sort(B_first(v1, 2)');
end