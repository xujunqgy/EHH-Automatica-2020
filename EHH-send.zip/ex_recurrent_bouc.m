%--ex_boucWen.m---
clear
% generate the train data and test data
load('/Users/Jun/Downloads/EHH/data/bouc-wen.mat');
na = 10;%1;
nb = 10;
ulag = 0;

u_interval = [min(u), max(u)];%[-205,210];%
y_interval = [min(y), max(y)];%[-0.0025,0.0025];%
% u = (u-u_interval(1))/(u_interval(2)-u_interval(1));
% y = (y-y_interval(1))/(y_interval(2)-y_interval(1));
uval_multisine = uval_multisine';%-u_interval(1))/(u_interval(2)-u_interval(1));
yval_multisine = yval_multisine';%-y_interval(1))/(y_interval(2)-y_interval(1));
uval_sinesweep = uval_sinesweep';%-u_interval(1))/(u_interval(2)-u_interval(1));
yval_sinesweep = yval_sinesweep';%-y_interval(1))/(y_interval(2)-y_interval(1));

u = reshape(u,8192,5);
y = reshape(y,8192,5);
ut = u(:, 1);
yt = y(:, 1);
[phi, yphi]=arrange_uy(ut, yt, na, nb, u_interval, y_interval,ulag);

dim = size(phi,2);
Ntrain=length(yphi);
Ntest1=length(yval_multisine);
Ntest2=length(yval_sinesweep);

%% Parameter Initialiation
config_file = 'config.ini';
parameters = init_par(config_file);
penalty = parameters.penalty;  % complexity penalty
num_train = parameters.num_train;  % number of training
percent = parameters.percent; % percentage of training data
parameters.lambda=[0,1e-8,1e-7,1e-6,1e-4];%; should be tuned for specific problem?

%% train of the recurrent network
for ii = 1:1000
x_train = phi;
y_train = yphi;
[B, weights, id_var_bb, stem_B, adjacency_matrix, id_layer, lof, err, stds, lambda_opt] = forward(x_train, y_train, parameters);
ysim = sys_simulation_ehh(na, nb, ut, yt, B, stem_B, weights, u_interval, y_interval,ulag);
[phi, yphi]=arrange_uy(ut, ysim, na, nb, u_interval, y_interval,ulag);
Esim(ii) = norm(ysim - yt)^2/norm(yt - mean(yt))^2;
end

 ysim1 = sys_simulation_ehh(na, nb, uval_multisine, yval_multisine, B, stem_B, weights, u_interval, y_interval,ulag);
     err_sim1 = sqrt(norm(ysim1-yval_multisine)^2/Ntest1);%*(y_interval(2)-y_interval(1));




