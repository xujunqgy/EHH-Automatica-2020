%--ex_boucWen.m---
clear
%% generate the train data and test data
load('/Users/Jun/Downloads/EHH/data/bouc-wen.mat');

% umin = min(u); umax = max(u);
% ymin = min(y); ymax = max(y);
% u = (u - umin)/(umax - umin);
% y = (y - ymin)/(ymax - ymin);
u = reshape(u,8192,5);
y = reshape(y,8192,5);

dbstop if error


[phi, xphi, yphi, ps] = arrange_state(u(:,1), y(:,1)); %x_i(t)=f_i(phi(t)), y(t)=x_1(t-1)


uval_multisine = uval_multisine';% - umin)/(umax - umin);
yval_multisine = yval_multisine';% - ymin)/(ymax - ymin);
uval_sinesweep = uval_sinesweep';% - umin)/(umax - umin);
yval_sinesweep = yval_sinesweep';% - ymin)/(ymax - ymin);

dim = size(phi,2);
Ntrain=length(yphi);
Ntest1=length(yval_multisine);
Ntest2=length(yval_sinesweep);

%% Parameter Initialiation
config_file = 'config.ini';
parameters = init_par(config_file);
num_train = parameters.num_train;  % number of training
parameters.lambda=[0,1e-8,1e-7,1e-6,1e-4];%; should be tuned for specific problem?

num_train = size(xphi,2);

% structure_candidate={0};%, [20]};%,50};%, 50, [50, 50]};%,[50]};0,[100],
% nstructure=length(structure_candidate);

adjacency_matrices = cell(num_train, 1);
stem_Bs = cell(num_train, 1);
Bs = cell(num_train, 1);
layer_indices = cell(num_train, 1);
weights_all = cell(num_train, 1);
yahh1 = zeros(length(yval_multisine), num_train);
yahh2 = zeros(length(yval_sinesweep), num_train);
err_test1 = zeros(num_train, 1);
err_test2 = err_test1;

% Bs{1}=[1 2 0];
% stem_Bs{1}=[0 0];
% weights_all{1}=[0,1]';


for ii = 1: num_train
    x_train = phi;
    y_train = xphi(:,ii);
    
    [B, weights, id_var_bb, stem_B, adjacency_matrix, id_layer, lof, err, stds, lambda_opt] = forward(x_train, y_train, parameters);
    
  
    adjacency_matrices{ii} = adjacency_matrix;
    stem_Bs{ii} = stem_B;
    Bs{ii} = B;
    layer_indices{ii} = id_layer;
    LAYERS{ii}=[B, num2cell(id_layer,2), num2cell(stem_B,2)];
%     LAYERS=LAYERS';
    weights_all{ii} = weights;    
end

ysim1 = sys_simulation_ehh_state(uval_multisine, yval_multisine, Bs, stem_Bs, weights_all,ps);
ysim2 = sys_simulation_ehh_state(uval_sinesweep, yval_sinesweep, Bs, stem_Bs, weights_all,ps);

ymax = ps.xmax(1); ymin = ps.xmin(1);
ysim1 = ysim1*(ymax-ymin) + ymin;
ysim2 = ysim2*(ymax-ymin) + ymin;

err_sim1 = sqrt(norm(ysim1-yval_multisine)^2/Ntest1);%*(y_interval(2)-y_interval(1));
err_sim2 = sqrt(norm(ysim2-yval_sinesweep)^2/Ntest2);%*(y_interval(2)-y_interval(1));

 
figure
plot(yval_multisine(7001:end),'k:','linewidth',1.5)
hold on
plot(ysim1(7001:end),'linewidth',1.5)
xlabel('Times Instant','fontsize',14)
ylabel('The outputs','fontsize',14)

figure
plot(yval_sinesweep,'k:','linewidth',1.5)%(7001:end)
hold on
plot(ysim2,'linewidth',1.5)
xlabel('Times Instant','fontsize',14)
ylabel('The outputs','fontsize',14)


