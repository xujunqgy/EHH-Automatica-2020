function [phi, yphi]=arrange_phi(u, y, u_id, y_id, u_interval, y_interval)
% arranged train data
% na and nb may be intervals for u and y
umin = u_interval(1);%min(u);floor(min(u));
umax = u_interval(2);%max(u);%%ceil(max(u));
ymin = y_interval(1);%min(y);%-0.0025;%floor(min(y));
ymax = y_interval(2);%max(y);%0.0025;%ceil(max(y));

Lt=length(u);


u = reshape(u,Lt,1);
y = reshape(y,Lt,1);
nstart = max(max(y_id),max(u_id));

for t=nstart+1:Lt
    id=t-nstart;
    reg1 = (y(t-y_id)-ymin)/(ymax - ymin);
    reg2 = (u(t-u_id)-umin)/(umax - umin);
    phi(id,:)=[reg1', reg2'];
end
yphi=y(nstart+1: Lt);