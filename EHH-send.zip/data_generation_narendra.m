function [u, yout, u_v, y_v]=data_generation_narendra(L);
%--data generation--

var_n = 0.1;

x1( 1 ) = 0; x2( 1 ) = 0; % the initial value of the states

% for t = 1 : L
%     u( t ) = unifrnd(-2.5, 2.5 );
% end
u = unifrnd(-2,2,L,1);

for t = 1 : L - 1
    x1( t + 1 ) = ( x1( t ) / ( 1 + x1( t )^2 ) + 1 ) * sin( x2( t ) );
    x2( t + 1 ) = x2( t ) * cos( x2( t ) ) + x1( t ) * exp( -( x1( t )^2 + x2( t )^2 ) / 8 ) + u( t )^3 / ( 1 + u( t )^2 + 0.5 * cos( x1( t ) + x2( t ) ) );
    yout( t ) = x1( t ) / ( 1 + 0.5 * sin( x2( t ) ) ) + x2( t ) / ( 1 + 0.5 * sin( x1( t ) ) ) + normrnd( 0, sqrt( var_n ) );
end

yout( L ) = x1( L ) / ( 1 + 0.5 * sin( x2( L ) ) ) + x2( L ) / ( 1 + 0.5 * sin( x1( L ) ) ) + normrnd( 0, sqrt( var_n ) );

L2 = 200;
u_v = [];

for t = 1 : L2
    u_v( t ) = sin( 2 * pi * t / 10 ) + sin( 2 * pi * t / 25 );
end

% u = u( 1 : 200 );

x1_v( 1 ) = 0; x2_v( 1 ) = 0;

for t = 1 : L2 - 1
    x1_v( t + 1 ) = ( x1_v( t ) / ( 1 + x1_v( t )^2 ) + 1 ) * sin( x2_v( t ) );
    x2_v( t + 1 ) = x2_v( t ) * cos( x2_v( t ) ) + x1_v( t ) * exp( - ( x1_v( t )^2 + x2_v( t )^2 ) / 8 ) + u_v( t )^3 / ( 1 + u_v( t )^2 + 0.5 * cos( x1_v( t ) + x2_v( t ) ) );
    y_v( t ) = x1_v( t ) / ( 1 + 0.5 * sin( x2_v( t ) ) ) + x2_v( t ) / ( 1 + 0.5 * sin( x1_v( t ) ) ) + normrnd( 0, sqrt( 0.1 ) );
end

y_v( L2 ) = x1_v( L2 ) / ( 1 + 0.5 * sin( x2_v( L2 ) ) ) + x2_v( L2 ) / ( 1 + 0.5 * sin( x1_v( L2 ) ) ) + normrnd( 0, sqrt( 0.1 ) ) ;
