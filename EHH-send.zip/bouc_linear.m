clear
% generate the train data and test data
load('/Users/Jun/Downloads/EHH/data/bouc-wen.mat');
na=10;%1;
nb=10;

uval_multisine = uval_multisine';
yval_multisine = yval_multisine';
uval_sinesweep = uval_sinesweep';
yval_sinesweep = yval_sinesweep';

u_interval = [-205,210];%[min(u), max(u)];%
y_interval = [-0.0025,0.0025];%[min(y), max(y)];%
% u = (u-u_interval(1))/(u_interval(2)-u_interval(1));
% y = (y-y_interval(1))/(y_interval(2)-y_interval(1));

ulag=1;
[phi, yphi]=arrange_uy(u, y, na, nb, u_interval, y_interval,ulag);


H=[ones(length(yphi),1),phi];
alpha=H\yphi;
ypre=H*alpha;
[phi_v, yphi_v]=arrange_uy(uval_multisine, yval_multisine, na,nb,u_interval,y_interval,ulag);
Hv=[ones(length(yphi_v),1),phi_v];
ypre_v=Hv*alpha;
sqrt(norm(ypre_v-yphi_v)^2/length(yphi_v))
ysim=sys_simulation_linear(na, nb, uval_multisine, yval_multisine, alpha, u_interval, y_interval,ulag);
1-sqrt(norm(ysim-yval_multisine)^2/norm(yval_multisine-mean(yval_multisine))^2)