function ysim=sys_simulation_linear(na, nb, u_v, y_v, alpha, u_interval, y_interval,ulag)

Lv = length(u_v);
u_v = reshape(u_v, Lv, 1);
y_v = reshape(y_v, Lv, 1);
umin = u_interval(1);
umax = u_interval(2);
ymin = y_interval(1);
ymax = y_interval(2);
ysim = zeros(Lv, 1);

ns = max(na,nb);
xsim = zeros(Lv, na+nb+1-ulag);
ysim(1:ns)=y_v(1:ns);

for t = ns+1 : Lv
    reg1 = (ysim(t-1:-1:t-nb)-ymin)/(ymax - ymin);
    %         reg2 = (u_v(t-1:-1:t-na)-umin)/(umax-umin);
    reg2 = (u_v(t-ulag:-1:t-na)-umin)/(umax-umin);
    xsim( t, : ) = [ reg1', reg2'];
    ysim( t ) = [1 xsim(t,:)]*alpha;
end
