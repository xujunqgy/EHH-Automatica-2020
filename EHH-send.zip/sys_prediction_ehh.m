function ypre=sys_prediction_ehh(na, nb, u_v, y_v, B, stem_B, weights, u_interval, y_interval,ulag)

Lv = length(u_v);
u_v = reshape(u_v, Lv, 1);
y_v = reshape(y_v, Lv, 1);
umin = u_interval(1);
umax = u_interval(2);
ymin = y_interval(1);
ymax = y_interval(2);
% ulag = 0;%2;

ypre = zeros(Lv, 1);

if length(na)==1 & length(nb)==1
    ns = max(na,nb);
    xpre = zeros(Lv, na+nb+1-ulag);
%     ypre(1:ns)=y_v(1:ns);

    for t = ns+1 : Lv
        reg1 = (y_v(t-1:-1:t-nb)-ymin)/(ymax - ymin);
%         reg2 = (u_v(t-1:-1:t-na)-umin)/(umax-umin);
        reg2 = (u_v(t-ulag:-1:t-na)-umin)/(umax-umin);
        xpre( t, : ) = [ reg1', reg2'];
        ypre( t ) = cal_node_value( B, stem_B, xpre(t, :) )*weights;
    end
else
    if isempty(na)
        ns = max(nb);
    else
        ns = max(max(nb), max(na));
    end
    xpre = zeros(Lv, length(na)+length(nb)+1);%+1 contains y(t)
%     ypre(1:ns)=y_v(1:ns);

    for t = ns+1:Lv
        reg1 = []; %reg2 = reg1;
        reg2 = u_v(t);
        for ii = 1: length(nb)
            reg1 = [reg1, (y_v(t-nb(ii))-ymin)/(ymax-ymin)];
        end
        for ii = 1:length(na)
            reg2 = [reg2, (u_v(t-na(ii))-umin)/(umax-umin)];
        end
        xpre( t, : ) = [reg1, reg2];
        ypre( t ) = cal_node_value( B, stem_B, xpre(t, :) )*weights;
    end
end

% ns = max(na, nb);
% ypre(1:ns)=y_v(1:ns);
% 
% for t = ns+1 : Lv
%     reg1 = y_v(t-1:-1:t-nb);%(y_v(t-1:-1:t-nb)-ymin)/(ymax - ymin);%
%     reg2 = u_v(t-1:-1:t-na);
%     xpre( t, : ) = [ reg1', reg2'];
%     ypre( t ) = cal_node_value( B, stem_B, xpre(t, :) )*weights;
% end
